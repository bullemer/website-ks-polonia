# Alternative B · Elektro-Bedarfskonzept E-04

Stand 13.11.2026 · bezogen auf Grundriss B-05 (Croatia und Polonia je 9,15 m tief; Querweg auf der ehemaligen Thekenfläche). **Vorschlag zur gemeinsamen Abstimmung, noch nicht von beiden Vereinen beschlossen.** Die 17 neuen Fotos unter `../images/20261113_*.jpg` wurden als Orientierung berücksichtigt. Aus Fotos lassen sich weder die vorhandenen Stromkreise noch genaue Anschlusspositionen oder die verfügbare Leistung ableiten.

## Unterlagen

- `elektro-konzept.pdf`: A3-Bedarfsplan für die gemeinsame Besprechung; SVG und PNG liegen daneben.
- `elektro-basis.csv`: alle vorgeschlagenen Steckdosen, Leuchten und Schalter mit Ort, Höhe, Nutzung und Funktionsgruppe. Die Spalten `Croatia_Entscheid` und `Polonia_Entscheid` beginnen mit `offen` und können je Position auf `ja` oder `nein` gesetzt werden. Der Generator liest diese Datei und überschreibt Entscheidungen nicht.
- `elektro-datenkabel.csv`: **genau zwei** separate Datenkabel D01 und D02 mit Quelle, Ziel und Entscheidungsspalten. Sie sind Teil des gemeinsamen Basisvorschlags, nicht zusätzliche Club-Wünsche.
- `elektro-wuensche-croatia.csv` und `elektro-wuensche-polonia.csv`: getrennte, leere Listen für zusätzliche Wünsche. Je Wunsch ein ID-Präfix `C` bzw. `P`, Typ (`Steckdose`, `Leuchte`, `Schalter`), Zweck, ungefährer Ort, Anzahl, Priorität und gewünschte Kostenübernahme eintragen. Noch unbekannte Koordinaten bleiben leer.

## Gemeinsamer Grundumfang

| Bereich | Steckdosen | Licht und Bedienung |
| --- | --- | --- |
| Croatia | TV/Medienreserve und zwei Nutzpunkte an Fensterpfeilern | Drei entblendete Grundlichtpunkte; eigener Schalter am Bereichszugang |
| Polonia | Strom/Daten am festen Stellplatz des mobilen TV und zwei Nutzpunkte an der Ostwand | Drei entblendete Grundlichtpunkte; eigener Schalter am Bereichszugang |
| Querweg und Eingang | Zwei zusätzliche Doppelsteckdosen an den festen Außenwänden der ehemaligen Thekenfläche; eine niedrig montierte Doppelsteckdose innen rechts neben Ausgang 1 als Reserve für gelegentliche Außenversorgung; WLAN-Access-Point als Anschlussmöglichkeit bei K1/K2 | Zwei Lichtpunkte am Querweg, ein Eingangslicht; Schaltstellen an beiden Ausgängen |
| Pantry Croatia und Polonia | Je zwei Arbeitsplatten-/Gerätepositionen (davon eine für das zeitweise genutzte mobile Induktionsfeld); je ein Getränkekühlschrank mit dauerhaftem Strom | Je ein Arbeitslicht und eigener Schalter |

Die 16 Steckdosenorte entsprechen **28 Einzelsteckplätzen**; hinzu kommen 11 vorgeschlagene Leuchten, 6 Schalter und **2 Datenkabel**. G07 versorgt nun ein kleines DSL-Modem M01 neben dem Steigschacht im hinteren Croatia-Bereich statt eines Netzwerkschranks im öffentlichen Bereich. `Funktionsgruppe` bezeichnet nur die gewünschte Bedienung bzw. Nutzung und **keinen festgelegten Stromkreis**. Anzahl, Leuchtentyp, Helligkeit, Schalttechnik, Lastverteilung und Absicherung sind noch zu bemessen. Die Pantry-Positionen für Kochfelder reservieren eine Nutzung; die Leistung hängt vom tatsächlich gewählten Gerät ab. Es ist kein fest installiertes Kochfeld vorgesehen.

G14 und G15 sind ein zusätzlicher Vorschlag für den gemeinsam genutzten ehemaligen Thekenbereich: je eine Doppelsteckdose an der westlichen und östlichen festen Wand. Beide Positionen stehen auf `offen` und sind vor Ort auf Fenster, Tür und freie Wege zu prüfen. Es sind keine Bodendosen oder Leitungen über den Querweg vorgesehen.

G16 ist als gemeinsame Doppelsteckdose innen an der festen Wand rechts neben Ausgang 1 auf ca. 0,30 m Höhe eingetragen. Der Wunsch dient einer gelegentlichen Versorgung der Außenanlage/Terrasse. Vor einer Zusage muss die Elektrofachplanung prüfen, wie eine Leitung durch die Tür und im Außenbereich ohne Beeinträchtigung von Türfunktion, Rettungsweg und Begehbarkeit geführt werden könnte. Als gesonderte Angebotsvariante sollte eine fest installierte Außensteckdose geprüft werden. Schutzmaßnahmen und Last sind vom Fachbetrieb festzulegen; [ELEKTRO+](https://www.elektro-plus.com/elektroplanung/elektroinstallation-im-aussenbereich) behandelt Außensteckdosen als eigene Planungsaufgabe. G16 steht für beide Vereine auf `offen`.

## Datenkabel: genau zwei

| ID | Quelle | Ziel | Zweck |
| --- | --- | --- | --- |
| D01 | M01 am Steigschacht, Croatia | Polonia-Bereich am festen Stellplatz des mobilen TV | Ein kabelgebundener Datenanschluss für Polonia am Stellplatz |
| D02 | M01 am Steigschacht, Croatia | Gemeinsamer Bereich bei K1/K2, hoch an Wand/Decke | Anschluss für einen möglichen WLAN-Access-Point |

Beide Kabel sollen einzeln vom Modemstandort zum jeweiligen Endpunkt führen; es sind **keine weiteren Datenkabel** in diesem Grundumfang vorgesehen. Der Plan markiert Quelle und Endpunkte, **keine festgelegte Trasse**. Leitungsweg, Länge, Brandschott, Befestigung und Zugang sind vor Ort mit der Fachplanung zu klären; das Modem soll neben dem Schacht montiert werden, nicht auf dem Brandschott. Vor der Gerätewahl ist zu prüfen, ob das DSL-Gerät zwei nutzbare LAN-Ports hat oder ein kleiner Switch benötigt wird. Für D02 braucht der Access Point eine passende Stromversorgung: PoE mit geeigneter Einspeisung am Modemstandort oder einen gesondert zu planenden lokalen Stromanschluss. Die WLAN-Abdeckung ist erst im ausgebauten und belegten Raum zu prüfen.

Die bestehenden CLS-Sicherheitsleuchten, Rettungszeichen und der RWA-Taster gehören nicht zur frei schaltbaren Grundbeleuchtung. Sie sind vor Ort zu erfassen und in der weiteren Planung eigenständig zu behandeln. Der Bedarfsplan zeichnet weder Leitungen noch bestehende Steckdosen, weil deren genaue Lage und Versorgung nicht belegt sind.

## Wünsche Polonia

Der Elektroplan zeigt P01 bis P07 in Magenta; die Polonia-Wunschliste enthält: drei einzeln bedienbare Grundlichtpunkte L04–L06 mit Schaltern am Holzpfeiler, eine Doppelsteckdose am Pfeiler und je eine Doppelsteckdose in der hinteren linken und rechten Ecke sowie vorne rechts neben dem Fenster. Die Begriffe „hinten“ und „vorne“ sowie der genaue Fensterpfeiler sind vor Ort zu bestätigen; die eingezeichneten Wunschorte sind schematisch. Der TV steht voraussichtlich auf einem Rollständer. G09 und D01 liegen deshalb am festen Stellplatz an der Nordwand. Ein kabelgebundener Datenanschluss des TV ist nur dort vorgesehen. Die gewünschte Pfeilersteckdose P02 könnte den TV an einer zweiten Position versorgen, falls sie umgesetzt wird; Kabelführung und Nutzung sind vor Ort zu prüfen. Eine Leitung über den Querweg ist nicht geplant. Der Pfeiler ist eine Holzstütze; Befestigung und Leitungsweg müssen fachlich und statisch geprüft werden. Die Grundposition S04 ist mit der gewünschten Einzelbedienung abzustimmen. P06 ergänzt zwei feste Abschnitte indirekter, dimmbarer RGBW-LED-Beleuchtung an Nord- und Ostwand; P07 ist die eigene Farb- und Szenenbedienung. Weißes und farbiges Stimmungslicht sind damit unabhängig von den Grundlichtpunkten L04–L06. Profile, Lichtaustritt, Treiberstandort, Zugänglichkeit, Leistungsbedarf und Steuerung sind durch die Elektrofachplanung zu bestimmen. Die mobilen Trennelemente und der TV tragen keine LED-Bänder. Diese Positionen sind Wünsche von Polonia und nicht Teil des gemeinsamen Basisumfangs.

## Abstimmung und Ergänzungen

1. Beide Vereine prüfen **jede Basiszeile** in `elektro-basis.csv` und beide Kabel in `elektro-datenkabel.csv`. Erst zwei `ja` bedeuten „gemeinsam angenommen“; bei `nein` oder `offen` bleibt die Position zur Klärung.
2. Jeder Verein ergänzt eigene Wünsche ausschließlich in seiner Wunschliste. Zusätze an gemeinsam genutzten Anlagen oder in Verkehrswegen werden von beiden Vereinen abgestimmt.
3. Die Elektrofachplanung bewertet Bestand, Gerätelasten, Anzahl und Führung der Stromkreise, Schutzmaßnahmen, Montage, Lichtberechnung und Kosten. Sie trägt geprüfte Zusatzwünsche in eine nächste Planfassung ein.
4. Vor Ausführung: tatsächliche Wand- und Fensterpfeiler, Träger, Pantryanschlüsse, beide Türen, Querweg, vorhandene CLS-/RWA-Anlage und Verteiler vor Ort aufnehmen. Keine Verlängerungsleitungen über den Querweg.

## Fachliche Grundlagen

Die [DKE](https://www.dke.de/de/arbeitsfelder/core-safety/din-vde-0100-normenreihe-sicherheit-schutz-elektroinstallation) beschreibt DIN VDE 0100 als maßgebliche Normenreihe für Niederspannungsanlagen auch in gewerblichen und öffentlichen Gebäuden; die [Erstprüfung](https://www.dke.de/de/normen-standards/dokument?id=7089969&type=dke%7Cdokument) umfasst Besichtigen, Erproben und Messen. Die [HEA-Küchenplanung](https://www.hea.de/fachwissen/kuechenplanung/elektroinstallationen) empfiehlt, Anschlusswerte der Geräte früh zu klären und leistungsstarke Verbraucher in der Stromkreisplanung gesondert zu berücksichtigen. Für die Nutzung als Arbeitsstätte sind die [BAuA-Hinweise zur Beleuchtung](https://www.baua.de/DE/Themen/Arbeitsgestaltung/Gefaehrdungsbeurteilung/Handbuch-Gefaehrdungsbeurteilung/Expertenwissen/Arbeitsumgebungsbedingungen/Beleuchtung-Licht/Beleuchtung-Licht_dossier?pos=2) und zur Sicherheitsbeleuchtung der Fluchtwege relevant. Welche Anforderungen hier konkret gelten, klären Fachplanung und Betreiber anhand der tatsächlichen Nutzung.

Regenerieren: `python scripts/build_elektro_3bereiche.py` aus dem Projektverzeichnis. Die Wunschlisten und Entscheidungen in der Basis-CSV bleiben erhalten.

## 3D-Modell

Der Viewer `index.html` liest `elektro-modell.json`, das zusammen mit dem PDF aus den CSVs generiert wird. Er zeigt alle 16 Basis-Steckdosenorte, 11 Leuchten, 6 Basis-Schalter, M01, D01/D02 sowie P01–P07. Die Leuchten L04–L06 lassen sich zur Veranschaulichung einzeln schalten; die indirekten RGBW-Bänder können separat mit Weiß, Rot, Blau und Grün simuliert werden. Der mobile Polonia-TV hat einen Stellplatz und eine zweite exemplarische Nutzposition. Einblendungen und GLB-Export enthalten die Elektroobjekte; Leitungswege und Stromkreise werden nicht modelliert.

Die Wahl von RGBW folgt der [licht.de-Erläuterung zur RGB-Farbmischung](https://www.licht.de/de/grundlagen/lichtlexikon/details-lichtlexikon/rgb-farbmischung): Der zusätzliche Weißkanal erlaubt eine bessere weiße Lichtfarbe neben farbigen Szenen. Die indirekten Bänder sind Stimmungslicht und ersetzen das Grundlicht nicht.
